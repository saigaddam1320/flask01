#import the Flask class and create an instance of it

#define homepage route and index() view function

#run the app in debug mode
